import React from 'react';

export interface CalendarProps {
  style?: React.CSSProperties; // 自定义样式
  yearsRange:number[];//
}


declare const Calendar: React.FC<CalendarProps>;

export default Calendar;
